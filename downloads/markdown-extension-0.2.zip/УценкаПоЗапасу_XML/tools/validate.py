from pathlib import Path
import re, uuid, xml.etree.ElementTree as E
root=Path(__file__).resolve().parents[1]/'src'
ns={'m':'http://v8.1c.ru/8.3/MDClasses'}
files=list(root.rglob('*.xml'));ids=set()
for file in files:
 tree=E.parse(file)
 for el in tree.iter():
  if 'uuid' in el.attrib:
   value=el.attrib['uuid'];uuid.UUID(value)
   assert value not in ids, ('duplicate UUID',file,value)
   ids.add(value)
  if el.tag.split('}')[-1] in ('TypeId','ValueId','ObjectId'):
   value=el.text;uuid.UUID(value)
   assert value not in ids, ('duplicate type/object UUID',file,value)
   ids.add(value)
  assert not el.tag.endswith('ExtendedConfigurationObject'), ('unexpected borrowed object',file)
config=E.parse(root/'Configuration.xml').getroot()
folders={'CommonModule':'CommonModules','CommonForm':'CommonForms','InformationRegister':'InformationRegisters','CommonCommand':'CommonCommands','Subsystem':'Subsystems'}
for child in config.find('m:Configuration/m:ChildObjects',ns):
 kind=child.tag.split('}')[-1];name=child.text
 assert kind in folders,kind
 p=root/folders[kind]/(name+'.xml');assert p.is_file(),p
 obj=E.parse(p).getroot().find('m:'+kind,ns)
 assert obj.find('m:Properties/m:Name',ns).text==name,p
 if kind=='CommonModule':assert (p.with_suffix('')/'Ext/Module.bsl').is_file(),p
 if kind=='CommonCommand':assert (p.with_suffix('')/'Ext/CommandModule.bsl').is_file(),p
 if kind=='CommonForm':
  assert (p.with_suffix('')/'Ext/Form.xml').is_file(),p
  assert (p.with_suffix('')/'Ext/Form/Module.bsl').is_file(),p
adapter=(root/'CommonModules/УЗ_УТ/Ext/Module.bsl').read_text(encoding='utf-8-sig')
exports=set(re.findall(r'Функция\s+(\w+)\(',adapter))
for p in root.rglob('*.bsl'):
 for called in re.findall(r'УЗ_УТ\.(\w+)\(',p.read_text(encoding='utf-8-sig')):
  assert called in exports,(p,called)
print(f'OK: {len(files)} XML files, {len(ids)} unique metadata UUIDs; references and adapter entry points present.')
print('Not checked: Designer import, BSL compilation, XSD, UT data, documents, tasks or scheduling.')
